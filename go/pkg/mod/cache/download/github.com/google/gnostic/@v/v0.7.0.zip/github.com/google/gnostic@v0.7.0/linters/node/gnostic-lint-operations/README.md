This directory contains a gnostic linter written with node.

It is built using
[dcodeIO/Protobuf.js](https://github.com/dcodeIO/ProtoBuf.js).

### SETUP

- Install node.
- Run `make setup` to install node dependencies.

### TRY IT

- Run `make run` to test-run the plugin.

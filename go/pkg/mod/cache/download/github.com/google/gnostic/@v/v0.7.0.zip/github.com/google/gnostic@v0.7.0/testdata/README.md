# testdata

This directory contains test data used to verify gnostic.

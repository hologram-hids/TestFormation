The [development](./) directory holds documentation for cAdvisor developers and contributors. If you
are looking for development using cAdvisor (as opposed to development of cAdvisor), then these
documents probably don't apply to you.

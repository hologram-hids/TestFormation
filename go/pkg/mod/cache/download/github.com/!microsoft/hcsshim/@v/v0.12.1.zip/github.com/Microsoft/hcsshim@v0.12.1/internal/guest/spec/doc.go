// Package spec encapsulates a number of GCS specific oci spec modifications, e.g.,
// networking mounts, sandbox path substitutions in guest etc.
package spec

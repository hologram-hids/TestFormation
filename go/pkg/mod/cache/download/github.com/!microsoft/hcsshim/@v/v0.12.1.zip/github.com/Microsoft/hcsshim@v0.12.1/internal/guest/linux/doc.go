// Package linux contains definitions required for making a linux ioctl.
package linux

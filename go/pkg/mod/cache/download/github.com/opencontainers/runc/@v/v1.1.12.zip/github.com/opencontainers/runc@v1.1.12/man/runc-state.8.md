% runc-state "8"

# NAME
**runc-state** - show the state of a container

# SYNOPSIS
**runc state** _container-id_

# DESCRIPTION
The **state** command outputs current state information for the specified
_container-id_ in a JSON format.

# SEE ALSO

**runc**(8).

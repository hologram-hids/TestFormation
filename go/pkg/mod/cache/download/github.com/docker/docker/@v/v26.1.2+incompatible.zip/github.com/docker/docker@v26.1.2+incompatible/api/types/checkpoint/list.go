package checkpoint

// Summary represents the details of a checkpoint when listing endpoints.
type Summary struct {
	// Name is the name of the checkpoint.
	Name string
}
